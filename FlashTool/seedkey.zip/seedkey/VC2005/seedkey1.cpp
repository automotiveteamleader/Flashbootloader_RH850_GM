#include <windows.h>

extern "C" {
  //--------------------------------------------------------------------------------- 
  // ASAP1A_CCP_ComputeKeyFromSeed
  //
  // This function is called from the Flash Tool.
  //---------------------------------------------------------------------------------
  bool __declspec(dllexport) __cdecl ASAP1A_CCP_ComputeKeyFromSeed(char           * seed, 
                                                                   unsigned short   sizeSeed, 
                                                                   char           * key, 
                                                                   unsigned short   maxSizeKey, 
                                                                   unsigned short * sizeKey)
  {
    // Example calculation: Key = Negation  of Seed
    for (int i= 0; i < maxSizeKey; i++) {
		  if (i < sizeSeed) key[i]= ~seed[i];
	  }
    //-End of Calculation--------------------------

    *sizeKey= sizeSeed;

    // If the returnvalue is false the flash tool stops
	  return true;
  }
}

